import { Component } from '@angular/core';

@Component({
  selector: 'app-main',
  templateUrl: './main.container.html',
  styleUrls: ['./main.container.scss']
})
export class MainContainerComponent {}
