export interface ChainModel {
  id: string;
  name: string;
}
export interface ChainOperationalModel {
  name: string;
}
