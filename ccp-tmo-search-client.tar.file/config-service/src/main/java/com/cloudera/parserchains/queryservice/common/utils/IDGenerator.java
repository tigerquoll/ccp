package com.cloudera.parserchains.queryservice.common.utils;

public interface IDGenerator<T> {

  T incrementAndGet();
}
